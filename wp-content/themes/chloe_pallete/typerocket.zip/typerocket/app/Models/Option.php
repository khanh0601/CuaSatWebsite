<?php

namespace App\Models;

use TypeRocket\Models\WPOption;

class Option extends WPOption
{
}