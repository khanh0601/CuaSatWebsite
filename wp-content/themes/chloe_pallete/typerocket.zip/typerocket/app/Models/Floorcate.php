<?php
namespace App\Models;

use TypeRocket\Models\WPTerm;

class Floorcate extends WPTerm
{
    protected $taxonomy = 'floorcate';
}
